import React, { useEffect, useState } from 'react'
import { createRoot } from 'react-dom/client'
import {
  ArrowDownRight, ArrowRight, ArrowUpRight, Github, Linkedin, Mail,
  Menu, X, Code2, Terminal, Layers3, Braces, ExternalLink, Download,
  GraduationCap, Sparkles, MoveUpRight
} from 'lucide-react'
import './styles.css'

const projects = [
  {
    number: '01',
    title: 'FaceEntry Pro',
    category: 'BIOMETRIC · WEB APP',
    description: 'A smart campus attendance concept using facial recognition, with attendance history, reports, and role-based dashboards.',
    stack: ['Python', 'OpenCV', 'Flask', 'MySQL'],
    symbol: '◉',
    tone: 'mint',
    link: 'https://github.com/swejahid',
  },
  {
    number: '02',
    title: 'Large File Finder',
    category: 'DESKTOP · PRODUCTIVITY',
    description: 'A desktop utility concept for finding large files, reviewing folder usage, and identifying duplicate files.',
    stack: ['Electron', 'JavaScript', 'Node.js'],
    symbol: '⌘',
    tone: 'violet',
    link: 'https://github.com/swejahid',
  },
  {
    number: '03',
    title: 'Kundon Shoili',
    category: 'E-COMMERCE · FRONTEND',
    description: 'A Bengali-inspired bangle storefront concept focused on elegant product presentation and a smooth shopping journey.',
    stack: ['HTML', 'CSS', 'JavaScript'],
    symbol: '✳',
    tone: 'amber',
    link: 'https://github.com/enterprisejh09-ai/kundon-shoili',
  },
]

const skills = [
  { name: 'C / C++', level: 'Programming fundamentals', icon: Code2 },
  { name: 'Python', level: 'Scripting & computer vision', icon: Terminal },
  { name: 'JavaScript', level: 'Frontend & Node.js', icon: Braces },
  { name: 'React', level: 'Component-based UI', icon: Layers3 },
  { name: 'HTML & CSS', level: 'Responsive web design', icon: Code2 },
  { name: 'MySQL', level: 'Relational databases', icon: Terminal },
]

function App() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [active, setActive] = useState('Home')
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    const sections = ['home', 'about', 'skills', 'projects', 'contact']
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const label = entry.target.id.charAt(0).toUpperCase() + entry.target.id.slice(1)
          setActive(label)
        }
      })
    }, { rootMargin: '-35% 0px -55% 0px' })
    sections.forEach((id) => {
      const el = document.getElementById(id)
      if (el) observer.observe(el)
    })
    return () => observer.disconnect()
  }, [])

  const closeMenu = () => setMenuOpen(false)
  const email = 'hello@example.com'

  const copyEmail = async () => {
    try {
      await navigator.clipboard.writeText(email)
      setCopied(true)
      window.setTimeout(() => setCopied(false), 1800)
    } catch {
      window.location.href = `mailto:${email}`
    }
  }

  return (
    <div className="site-shell">
      <div className="ambient ambient-one" />
      <div className="ambient ambient-two" />
      <header className="topbar">
        <a className="brand" href="#home" aria-label="Jahid home" onClick={closeMenu}>
          <span className="brand-mark">J<span>.</span></span>
          <span className="brand-name">JAHID<span className="brand-dot">/</span>DEV</span>
        </a>
        <button className="mobile-menu" aria-label={menuOpen ? 'Close navigation' : 'Open navigation'} onClick={() => setMenuOpen(!menuOpen)}>
          {menuOpen ? <X size={21} /> : <Menu size={21} />}
        </button>
        <nav className={menuOpen ? 'nav-links nav-open' : 'nav-links'} aria-label="Main navigation">
          {['Home', 'About', 'Skills', 'Projects', 'Contact'].map((item) => (
            <a key={item} className={active === item ? 'nav-link active' : 'nav-link'} href={`#${item.toLowerCase()}`} onClick={closeMenu}>{item}</a>
          ))}
          <a className="nav-cta" href="#contact" onClick={closeMenu}>Let's talk <ArrowUpRight size={15} /></a>
        </nav>
      </header>

      <main>
        <section className="hero section-wrap" id="home">
          <div className="hero-copy reveal">
            <div className="availability"><span className="pulse-dot" /> OPEN TO LEARNING & OPPORTUNITIES</div>
            <p className="eyebrow">HELLO, I'M JAHID HOSSAIN</p>
            <h1>Building digital<br />things with <span className="green-word">purpose.</span></h1>
            <p className="hero-description">I'm a Software Engineering student who enjoys turning ideas into thoughtful, useful digital experiences — one line of code at a time.</p>
            <div className="hero-actions">
              <a className="button button-primary" href="#projects">Explore my work <ArrowDownRight size={17} /></a>
              <a className="button button-ghost" href="#contact">Get in touch <ArrowUpRight size={16} /></a>
            </div>
            <div className="hero-socials">
              <a href="https://github.com/swejahid" target="_blank" rel="noreferrer"><Github size={17} /> GitHub <ArrowUpRight size={12} /></a>
              <span className="social-divider" />
              <a href="https://www.linkedin.com/in/md-jahid-hossain-98b057367" target="_blank" rel="noreferrer"><Linkedin size={16} /> LinkedIn <ArrowUpRight size={12} /></a>
            </div>
          </div>

          <div className="hero-visual reveal delay-one">
            <div className="visual-grid" />
            <div className="orbit orbit-outer" />
            <div className="orbit orbit-inner" />
            <div className="profile-card">
              <div className="profile-top"><span>PROFILE_001</span><span className="live-label"><span /> ONLINE</span></div>
              <div className="avatar-wrap">
                <div className="avatar-ring"><div className="avatar">J<span>.</span></div></div>
                <span className="avatar-star star-one">✳</span><span className="avatar-star star-two">✦</span>
              </div>
              <h2>Md Jahid Hossain</h2>
              <p className="profile-role">Software Engineering Student</p>
              <div className="profile-rule" />
              <div className="profile-meta"><span>BASED IN</span><strong>Bangladesh 🇧🇩</strong></div>
              <div className="profile-meta"><span>FOCUS</span><strong>Software · Web · Problem Solving</strong></div>
              <div className="profile-footer"><span className="tiny-code">const passion = "build";</span><Sparkles size={15} /></div>
            </div>
            <div className="float-chip chip-code"><Code2 size={15} /> <span>Clean code</span></div>
            <div className="float-chip chip-build"><span className="chip-dot" /> Always building</div>
            <div className="visual-caption"><span>01 / 05</span><span>SCROLL TO EXPLORE <ArrowDownRight size={13} /></span></div>
          </div>
          <a className="scroll-cue" href="#about"><span className="scroll-line" /> SCROLL DOWN</a>
        </section>

        <section className="about section-wrap section-block" id="about">
          <div className="section-heading reveal">
            <p className="eyebrow"><span>01</span> / A LITTLE ABOUT ME</p>
            <h2>Curious mind.<br /><span className="muted-heading">Builder's mindset.</span></h2>
          </div>
          <div className="about-content reveal delay-one">
            <p className="about-lead">I’m learning how to build technology that solves real problems — from practical web interfaces to software tools that make everyday tasks easier.</p>
            <p className="body-copy">Currently studying Software Engineering at Daffodil International University, I’m growing my skills in programming, web development, databases, and software design. I believe good work comes from staying curious, learning by building, and improving a little every day.</p>
            <div className="about-facts">
              <div className="fact"><span className="fact-number">01</span><div><strong>Learn by building</strong><p>Small experiments, real projects.</p></div></div>
              <div className="fact"><span className="fact-number">02</span><div><strong>Keep it practical</strong><p>Useful beats complicated.</p></div></div>
              <div className="fact"><span className="fact-number">03</span><div><strong>Always improve</strong><p>One iteration at a time.</p></div></div>
            </div>
          </div>
        </section>

        <section className="education-strip section-wrap reveal">
          <div className="edu-icon"><GraduationCap size={22} /></div>
          <div className="edu-copy"><span className="eyebrow">CURRENTLY STUDYING</span><strong>B.Sc. in Software Engineering</strong><p>Daffodil International University · Bangladesh</p></div>
          <span className="edu-status"><span className="pulse-dot" /> IN PROGRESS</span>
        </section>

        <section className="skills section-wrap section-block" id="skills">
          <div className="section-heading reveal">
            <p className="eyebrow"><span>02</span> / MY TOOLKIT</p>
            <h2>Tools I use to<br /><span className="muted-heading">bring ideas to life.</span></h2>
          </div>
          <div className="skills-area">
            <p className="skills-intro reveal">A growing toolkit for building, experimenting, and solving problems. These are the technologies I’m currently exploring and using in my work.</p>
            <div className="skills-grid">
              {skills.map(({ name, level, icon: Icon }, i) => (
                <div className="skill-card reveal" style={{ '--delay': `${i * 70}ms` }} key={name}>
                  <div className="skill-icon"><Icon size={20} strokeWidth={1.7} /></div>
                  <div><h3>{name}</h3><p>{level}</p></div>
                  <ArrowUpRight className="skill-arrow" size={16} />
                </div>
              ))}
            </div>
            <div className="learning-note"><span className="note-spark">✳</span><p><strong>Always in progress.</strong> This toolkit evolves as I learn new concepts and build new projects.</p></div>
          </div>
        </section>

        <section className="projects section-wrap section-block" id="projects">
          <div className="projects-heading reveal">
            <div className="section-heading">
              <p className="eyebrow"><span>03</span> / SELECTED WORK</p>
              <h2>Things I've been<br /><span className="muted-heading">working on.</span></h2>
            </div>
            <a className="text-link" href="https://github.com/swejahid" target="_blank" rel="noreferrer">More on GitHub <ArrowUpRight size={16} /></a>
          </div>
          <div className="project-grid">
            {projects.map((project) => (
              <article className={`project-card ${project.tone} reveal`} key={project.number}>
                <div className="project-card-top"><span className="project-number">PROJECT / {project.number}</span><a href={project.link} target="_blank" rel="noreferrer" aria-label={`Open ${project.title} repository`}><ArrowUpRight size={18} /></a></div>
                <div className="project-art"><div className="art-orbit art-orbit-one" /><div className="art-orbit art-orbit-two" /><span className="project-symbol">{project.symbol}</span><span className="art-caption">J / LAB</span></div>
                <div className="project-details">
                  <p className="project-category">{project.category}</p>
                  <h3>{project.title}</h3>
                  <p className="project-description">{project.description}</p>
                  <div className="tag-list">{project.stack.map((tag) => <span key={tag}>{tag}</span>)}</div>
                  <a className="project-link" href={project.link} target="_blank" rel="noreferrer">View project <ArrowRight size={15} /></a>
                </div>
              </article>
            ))}
          </div>
          <p className="project-disclaimer">Project summaries describe the intended scope; update repository links and status as each project evolves.</p>
        </section>

        <section className="contact section-wrap section-block" id="contact">
          <div className="contact-panel reveal">
            <div className="contact-glow" />
            <div className="contact-content">
              <p className="eyebrow"><span>04</span> / WHAT'S NEXT?</p>
              <h2>Have an idea?<br /><span className="green-word">Let's build it.</span></h2>
              <p className="contact-description">I’m always happy to connect with people who enjoy technology, share ideas, and build meaningful things. Drop me a message.</p>
              <div className="contact-actions">
                <button className="button button-primary" onClick={copyEmail}><Mail size={17} /> {copied ? 'Email copied!' : 'Copy email'} <ArrowUpRight size={15} /></button>
                <a className="button button-ghost" href="https://github.com/swejahid" target="_blank" rel="noreferrer">Find me on GitHub <Github size={16} /></a>
              </div>
              <p className="email-hint">Remember to replace <code>hello@example.com</code> with your real email in <code>src/main.jsx</code>.</p>
            </div>
            <div className="contact-decoration"><span>J</span><div className="decoration-cross">✳</div></div>
          </div>
        </section>
      </main>

      <footer className="footer section-wrap">
        <a className="brand footer-brand" href="#home"><span className="brand-mark">J<span>.</span></span><span className="brand-name">JAHID<span className="brand-dot">/</span>DEV</span></a>
        <p>Designed & built with <span className="heart">♥</span> and a lot of curiosity.</p>
        <a className="back-top" href="#home">BACK TO TOP <MoveUpRight size={13} /></a>
        <span className="footer-copy">© {new Date().getFullYear()} JAHID</span>
      </footer>
    </div>
  )
}

createRoot(document.getElementById('root')).render(<React.StrictMode><App /></React.StrictMode>)